# Graph - Group 12

Complex Networks Project 2016/2017 - "Graph" - Técnico Lisboa

### Requirements

This project requires and updated version of Java (1.8+) and JavaFX

### Project compile

```sh
$ make
```

### Execute the project

```sh
$ java -cp build/ Graph
```